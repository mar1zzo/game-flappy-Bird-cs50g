#define SDL_REVISION "hg-0:aaaaaaaaaaah"
#define SDL_REVISION_NUMBER 0
